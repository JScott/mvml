window.onload = function() {
  log.setLevel('trace');
  MVML.init();
  MVML.load_tag();  
}
